import numpy as np

# Fuzzy Set Operations
def fuzzy_union(set1, set2):
    return np.maximum(set1, set2)

def fuzzy_intersection(set1, set2):
    return np.minimum(set1, set2)

def fuzzy_complement(set1):
    return 1 - set1

def fuzzy_difference(set1, set2):
    return np.maximum(set1, 1 - set2)

# Fuzzy Relations
def fuzzy_relation_cartesian(set1, set2):
    cartesian_product = np.multiply.outer(set1, set2)
    return cartesian_product

def max_min_composition(relation1, relation2):
    return np.max(np.minimum.outer(relation1, relation2), axis=1)

# Example usage
setA = np.array([0.2, 0.5, 0.8])
setB = np.array([1, 6, 0.9])

# Fuzzy Set Operations
union_result = fuzzy_union(setA, setB)
intersection_result = fuzzy_intersection(setA, setB)
complement_result = fuzzy_complement(setA)
difference_result = fuzzy_difference(setA, setB)

print("Union:", union_result)
print("Intersection:", intersection_result)
print("Complement:", complement_result)
print("Difference:", difference_result)

# Fuzzy Relations
relationAB = fuzzy_relation_cartesian(setA, setB)
relationBA = fuzzy_relation_cartesian(setB, setA)
composition_result = max_min_composition(relationAB, relationBA)

print("\nFuzzy Relation (A x B):\n", relationAB)
print("\nFuzzy Relation (B x A):\n", relationBA)
print("\nMax-Min Composition Result:\n", composition_result)
