import Pyro4

@Pyro4.expose
class StringConcatenationServer(object):
    def concatenate_strings(self, str1, str2):
        return str1 + str2

daemon = Pyro4.Daemon()
uri = daemon.register(StringConcatenationServer)
print(f"Ready. Object URI = {uri}")
daemon.requestLoop()

###rmi client

import Pyro4

server = Pyro4.Proxy("PYROURI:obj_625c9c96eee6")  # Replace with the URI printed by the server
str1 = "Hello"
str2 = "World"
result = server.concatenate_strings(str1, str2)
print(f"Concatenated string: {result}")