import numpy as np

# Generate antibodies
def create_antibody(size):
    return np.random.rand(size)

# Calculate affinity
def affinity(antibody, datapoint):
    return 1 / (1 + np.linalg.norm(antibody - datapoint))

# Generate data
healthy_data = np.array([[1.0, 2.0, 3.0], [1.1, 1.9, 3.2]])
num_antibodies = 10
antibody_population = [create_antibody(healthy_data.shape[1]) for _ in range(num_antibodies)]
damaged_data = np.array([[1.2, 1.7, 2.8], [1.4, 1.5, 3.5]])

# Simulate antibody evolution
for _ in range(2):
    healthy_affinities = [affinity(ab, dp) for ab in antibody_population for dp in healthy_data]
    top_antibodies = sorted(zip(antibody_population, healthy_affinities), key=lambda x: x[1], reverse=True)[:10]
    antibody_population = [ab + np.random.randn(ab.shape[0]) * 0.1 for ab, _ in top_antibodies]

# Check affinity for damaged data
damaged_affinities = [affinity(ab, damaged_data[0]) for ab in antibody_population]
# Identify potential damage
potential_damage_index = np.argmax(damaged_affinities)

print(len(antibody_population))
print("Potential damage detected with antibody:", antibody_population[potential_damage_index])
