from itertools import cycle

def round_robin_lb(servers, load):
    assignments = {s: 0 for s in servers}
    server_cycle = cycle(servers)
    for _ in range(load):
        current_server = next(server_cycle)
        assignments[current_server] += 1
    return assignments

def weighted_round_robin_lb(server_weights, load):
    assignments = {s: 0 for s in server_weights}
    weighted_servers = [server for server, weight in server_weights.items() for _ in range(weight)]
    server_cycle = cycle(weighted_servers)
    for _ in range(load):
        current_server = next(server_cycle)
        assignments[current_server] += 1
    return assignments

servers = ['s1', 's2', 's3']
weights = {'s1': 3, 's2': 2, 's3': 1}
load = 10
print("Round-robin assignments:", round_robin_lb(servers, load))
print("Weighted round-robin assignments:", weighted_round_robin_lb(weights, load))
