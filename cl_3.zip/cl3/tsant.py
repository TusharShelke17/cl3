import numpy as np

# Define the distance matrix between cities
distance_matrix = np.array([
    [0, 10, 15, 20],  # Distance from city 0 to cities 0, 1, 2, 3
    [10, 0, 35, 25],  # Distance from city 1 to cities 0, 1, 2, 3
    [15, 35, 0, 30],  # Distance from city 2 to cities 0, 1, 2, 3
    [20, 25, 30, 0]   # Distance from city 3 to cities 0, 1, 2, 3
])

# Initialize parameters
num_ants = 10
num_iterations = 100
alpha, beta, rho = 1.0, 3.0, 0.5
pheromone = np.ones_like(distance_matrix) / len(distance_matrix)
visibility = 1 / (distance_matrix + 1e-10)

# Run the Ant Colony Optimization algorithm
for _ in range(num_iterations):
    ant_tours = []
    for _ in range(num_ants):
        path, unvisited = [np.random.randint(len(distance_matrix))], set(range(len(distance_matrix)))
        unvisited.remove(path[0])
        while unvisited:
            probs = ((pheromone[path[-1], list(unvisited)] ** alpha) * (visibility[path[-1], list(unvisited)] ** beta))
            next_city = np.random.choice(list(unvisited), p=probs / np.sum(probs))
            path.append(next_city)
            unvisited.remove(next_city)
        path.append(path[0])
        length = np.sum(np.fromiter((distance_matrix[path[i], path[i + 1]] for i in range(len(path) - 1)), dtype=float))
        ant_tours.append((path, length))
        pheromone *= (1 - rho)
        pheromone[path[:-1], path[1:]] += 1 / length

# Find and print the shortest tour
shortest_tour = min(ant_tours, key=lambda x: x[1])
print("Shortest Tour:", shortest_tour[0])
print("Shortest Tour Length:", shortest_tour[1])
