##coconut 
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPRegressor
from geneticalgorithm import geneticalgorithm as ga

# Generate synthetic dataset
np.random.seed(42)
num_samples = 250
num_features = 4
true_coefficients = np.random.rand(num_features) * 10  # Random coefficients for features

# Generate synthetic features
X = np.random.rand(num_samples, num_features)

# Generate synthetic target variable (drying time)
# Here, we'll assume a linear relationship with some noise
noise = np.random.normal(loc=0, scale=1, size=num_samples)  # Gaussian noise
y = np.dot(X, true_coefficients) + noise

# Split the dataset into training and validation sets
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

def fitness_func(params):
    hidden_layer_sizes = (int(params[0]),) * int(params[1])
    activation = ['identity', 'logistic', 'tanh', 'relu'][int(params[2])]
    solver = ['lbfgs', 'sgd', 'adam'][int(params[3])]

    model = MLPRegressor(hidden_layer_sizes=hidden_layer_sizes, activation=activation, solver=solver)
    model.fit(X_train, y_train)

    fitness = -model.score(X_val, y_val)
    return fitness

varbound = np.array([[5, 10], [1, 3], [0, 3], [0, 2]])
algorithm_param = {'max_num_iteration': 20, 'population_size': 50, 'mutation_probability': 0.1,
                   'elit_ratio': 0.01, 'crossover_probability': 0.5, 'parents_portion': 0.3,
                   'crossover_type': 'uniform', 'max_iteration_without_improv': None}

model = ga(function=fitness_func, dimension=4, variable_type='int', variable_boundaries=varbound,
           algorithm_parameters=algorithm_param)

model.run()
best_params = model.output_dict['variable']

print("Best parameters found by genetic algorithm:", best_params)