##clonal

import random

def clonal_selection(population, fitness_func, num_generations, clone_rate, mutation_rate):
    population_size = len(population)

    for generation in range(num_generations):
        # Evaluate fitness of each individual
        fitness_scores = [fitness_func(individual) for individual in population]

        # Select parents based on fitness scores
        parents = [individual for individual, fitness in sorted(zip(population, fitness_scores), key=lambda x: x[1], reverse=True)[:population_size // 2]]

        # Clone and mutate selected parents
        offspring = []
        for parent in parents:
            for _ in range(clone_rate):
                clone = parent.copy()
                for i in range(len(clone)):
                    if random.random() < mutation_rate:
                        clone[i] = random.randint(0, 1)  # Assuming binary representation
                offspring.append(clone)

        # Create new population by combining parents and offspring (truncate if necessary)
        population = parents + offspring[:population_size - len(parents)]

    return population

# Example usage
population = [[random.randint(0, 1) for _ in range(5)] for _ in range(10)]  # Initial population of 10 individuals with 5 bits each

def fitness_func(individual):
    # Example fitness function: count number of ones
    return sum(individual)

print("Initial population:")
for individual in population:
    print(individual)

optimized_population = clonal_selection(population, fitness_func, num_generations=15, clone_rate=3, mutation_rate=0.1)
print("\nOptimized population:")
for individual in optimized_population:
    print(individual)